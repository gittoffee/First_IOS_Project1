
import UIKit

var scorestd : Int = 50
print (scorestd)
print ("Student , score is \(scorestd)")

scorestd = 80

var scoretexh = 200
let PI = 3.14
 //PI = 20 
var zooarray = ["horese" , "cat" , "tiger" , "lon"]
zooarray.count
var myanimal = zooarray[3]
zooarray .append("dog")
print("pet = \(zooarray)")

var pats = ""
for pats in zooarray{

}