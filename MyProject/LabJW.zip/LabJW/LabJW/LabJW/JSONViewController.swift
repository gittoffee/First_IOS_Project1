import UIKit

class JSONViewController: UIViewController {
    
    
    
    @IBOutlet weak var JSONLabel: UILabel!
    @IBOutlet weak var TextLabel: UILabel!
    @IBOutlet weak var PlistLabel: UILabel!
    @IBOutlet weak var InputTextField: UITextField!
    @IBOutlet weak var ShowTextFieldLabel: UILabel!
    
    
    

    override func viewDidLoad() {
        super.viewDidLoad()
    //  Connect to JSON
//    let urlString = "http://api.geonames.org/oceanJSON?formatted=true&lat=40.78343&lng=-43.96625&username=demo&style=full"
//    let session = URLSession.shared
//    let url = URL(string: urlString)
//    
//    let task = session.dataTask(with: URL)
        
        
        
//        {"ocean":
//            {"name": "North Atlantic Ocean"}
//        }
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
  
    
    
    @IBAction func ShowJSON(_ sender: Any) {
        let path = Bundle.main.path(forResource: "MyData", ofType: "json")
        let url = URL(fileURLWithPath: path!)
        
        let data = try! Data(contentsOf: url)
        let obj = try! JSONSerialization.jsonObject(with: <#T##Data#>, options: .allowFragments)
        
        if str = (obj) as! NSDictionary).Value.(value(forKey: message))
        self.JSONLabel.text = str as? String?? ""
    }
    
    @IBAction func ShowText(_ sender: Any) {
    }

    @IBAction func ShowPlist(_ sender: Any) {
    }

    @IBAction func ClickFinal(_ sender: Any) {
    }
    
    
}
