//
//  ViewController.swift
//  LabJW
//
//  Created by std111 on 5/23/17.
//  Copyright © 2017 std111. All rights reserved.
//

import UIKit

class ViewController: UIViewController , UITextFieldDelegate // 1 set UITextfieldDeligate
{
    
    @IBOutlet weak var MyimageView: UIImageView!  // 2
    @IBOutlet weak var ShowDatalabel: UILabel!    // 3
    @IBOutlet weak var InputData: UITextField!    // 4
    @IBOutlet weak var MyButton: UIButton!

    override func viewDidLoad()
    {
        super.viewDidLoad()
        self.InputData.delegate = self //6
    }

    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)   //10 Set keybord disappear
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true   //11 Set keyboard appear
    }
    
    @IBAction func ShowDataButton(_ sender: Any)   // 5
    {
        ShowDatalabel.text = InputData.text  //6   แสดงข้อมูล Text ใน Label as Text
        InputData.text = ""            //7  เคลียค่าในช่องกรอก
        InputData.isHidden = true    //8  ซ่อน ช่องกรอก
        MyButton.isHidden = true     //9  ซ่อนปุ่ม
        
    }
    
    
    override func didReceiveMemoryWarning()
    {
        super.didReceiveMemoryWarning()

    }


}

