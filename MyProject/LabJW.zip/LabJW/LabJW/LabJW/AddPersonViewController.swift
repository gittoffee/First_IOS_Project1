
import UIKit

class AddPersonViewController: UIViewController
{

    @IBOutlet weak var InputNameTextField: UITextField!
    @IBOutlet weak var InputIdField: UITextField!

    @IBOutlet weak var RTASwitch: UISwitch!
    @IBOutlet weak var RTARFLabel: UILabel!
    
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
    }

    @IBAction func TabSwitch(_ sender: Any)
    {
        if RTASwitch.isOn
        {
            RTARFLabel.text = "ภายใน บก.ทท."
            RTARFLabel.textColor = UIColor.green
        }
            else
            {
                RTARFLabel.text = "ภายนอก บก.ทท."
                RTARFLabel.textColor = UIColor.red
            }
    }
    
    @IBAction func SaveButton(_ sender: Any)
    {
//        let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
//        let member = Member(context: context)
//        member.id = InputIdField.text!
//        member.name = InputNameTextField.text!
//        member.isRTA = RTASwitch.isOn
//        
//        // save data to coreDATA
//        (UIApplication.shared.delegate as! AppDelegate).saveContext()
//        
//        navigationController!.popViewController(animated: true)    
    }


}
