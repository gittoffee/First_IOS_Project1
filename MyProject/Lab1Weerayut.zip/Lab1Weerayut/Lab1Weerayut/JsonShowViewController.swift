import UIKit

class JsonShowViewController: UIViewController {
    
    var urlString = "http://microblogging.wingnity.com/JSONParsingTutorial/jsonActors"
    
    

    override func viewDidLoad() {
        super.viewDidLoad()
        self.downloadJsonWithURL()

    }

    func downloadJsonWithURL(){
        let url = NSURL(string: urlString)
        URLSession.shared.dataTask(with: (url as? URL )!, completionHandler: { (data, response, error) in
            if let jsonObj = try? JSONSerialization.jsonObject(with: data!, options: .allowFragments) as? NSDictionary {
                print(jsonObj!.value(forKey: "actors") as Any)
            }
        }) .resume()
    
        
        
    }
}
