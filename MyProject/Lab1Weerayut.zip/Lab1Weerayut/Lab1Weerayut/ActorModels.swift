//
//  ActorModels.swift
//  Lab1Weerayut
//
//  Created by std111 on 5/26/17.
//  Copyright © 2017 weerayut krungklng. All rights reserved.
//

import Foundation

class ActorModel
{
    let name:String!
    let country:String!
    let height:String!
    let imageStr:String!
    
    init(name:String , country:String , height:String , img:String) {
        self.name = name
        self.country = country
        self.height = height
        self.imageStr = img
    }
    
}
